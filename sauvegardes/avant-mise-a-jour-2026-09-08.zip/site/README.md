# Site Cours SwiftUI

Site Next.js statique qui affiche les 84 fiches du dossier parent (`../*.md`).
Sortie : `out/` — prêt à héberger gratuitement sur Cloudflare Pages.

## Stack

- Next.js 14 (App Router, `output: "export"`)
- React 18
- TypeScript
- Tailwind CSS + `@tailwindcss/typography`
- `react-markdown` + `remark-gfm`
- `react-syntax-highlighter` (Prism + thème VS Code Dark+)

## Installation

```bash
cd site
npm install
```

## Développement

```bash
npm run dev
```

Ouvre [http://localhost:3000](http://localhost:3000).

Le site lit directement les fichiers `.md` du dossier parent
(`/Users/guillaumebourlart/Desktop/SwiftUI Cours/`). Le mapping fiche ↔
fichier vit dans `lib/sommaire.ts` — si tu ajoutes une nouvelle fiche, ajoute
son entrée là.

## Build statique

```bash
npm run build
```

Le site complet est généré dans `out/`. Aucune dépendance serveur, juste
HTML/CSS/JS.

## Déploiement Cloudflare Pages

Deux méthodes — la première est la plus simple.

### A. Drag and drop manuel

1. Va sur [Cloudflare Pages](https://dash.cloudflare.com/) → Workers & Pages
   → Create application → Pages → Upload assets.
2. Glisse-dépose le dossier `out/` complet.
3. C'est en ligne.

### B. Via Git (push to deploy)

1. Pousse le dossier `site/` (sans `node_modules` ni `out`) sur GitHub.
2. Sur Cloudflare Pages : Create application → Pages → Connect to Git.
3. Build settings :
   - Framework preset : **Next.js (Static HTML Export)**
   - Build command : `npm run build`
   - Build output directory : `out`
   - Root directory : `site` (si ton repo contient aussi les `.md` à la racine)
4. Note : si tu utilises ce chemin, Cloudflare doit aussi voir les `.md`
   du dossier parent. Il est plus simple dans ce cas de mettre tout le dépôt
   (les `.md` et `site/`) à la racine du repo Git, et de définir
   "Root directory" à `site` — le build fonctionnera car `..` pointera
   alors vers la racine du repo où vivent les fiches.

## Ajouter / mettre à jour une fiche

1. Crée ou modifie un fichier `.md` dans le dossier parent.
2. Si c'est une nouvelle fiche : ajoute son entrée dans `lib/sommaire.ts`
   (numéro, slug, titre, nom du fichier).
3. `npm run dev` ou `npm run build` reflète immédiatement.

## Structure

```
site/
├── app/
│   ├── globals.css
│   ├── layout.tsx          # shell HTML
│   ├── page.tsx            # accueil (index des parties)
│   └── fiche/
│       └── [slug]/page.tsx # page d'une fiche (généré pour chaque slug)
├── components/
│   ├── SiteShell.tsx       # layout client (mobile drawer state)
│   ├── Sidebar.tsx         # sommaire latéral fixe
│   ├── MobileHeader.tsx    # barre du haut mobile
│   ├── MarkdownRenderer.tsx
│   └── CodeBlock.tsx       # blocs de code copiables
├── lib/
│   ├── sommaire.ts         # registry des 84 fiches
│   └── fiches.ts           # lecture des .md
├── next.config.mjs
├── tailwind.config.ts
└── package.json
```
