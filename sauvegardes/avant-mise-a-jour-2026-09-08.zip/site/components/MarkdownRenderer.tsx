"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { CodeBlock } from "./CodeBlock";

export function MarkdownRenderer({ content }: { content: string }) {
  return (
    <div className="prose-fiche">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code(props) {
            const { className, children, ...rest } = props as {
              className?: string;
              children?: React.ReactNode;
              inline?: boolean;
            };
            const inline = (props as { inline?: boolean }).inline;
            const text = String(children ?? "").replace(/\n$/, "");
            const langMatch = /language-(\w+)/.exec(className ?? "");

            if (!inline && langMatch) {
              return <CodeBlock language={langMatch[1]} code={text} />;
            }

            if (!inline && !langMatch && text.includes("\n")) {
              return <CodeBlock code={text} />;
            }

            return (
              <code className={className} {...rest}>
                {children}
              </code>
            );
          },
          pre(props) {
            return <>{props.children}</>;
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
