# Lot SwiftUI 13.01 à 17.02

Fiches séparées générées pour la suite du cours SwiftUI orienté emploi.

- 13.01 — Intégrer UIKit dans SwiftUI
- 13.02 — Intégrer SwiftUI dans UIKit
- 14.01 — Pourquoi tester et XCTest
- 14.02 — Tester un ViewModel
- 14.03 — Tester un service avec mock
- 14.04 — Tester async/await simplement
- 15.01 — Xcode debugger, breakpoints et console
- 15.02 — Memory Graph, leaks et retain cycles
- 15.03 — Instruments Time Profiler
- 15.04 — Crashlytics, logs et erreurs non fatales
- 15.05 — Préparer une app pour l’App Store
- 16.01 — Git essentiel pour travailler en équipe
- 16.02 — Pull Request, code review et travail en équipe
- 16.03 — Agile, Scrum, Jira et organisation produit
- 16.04 — Dépendances iOS : Swift Package Manager et CocoaPods
- 16.05 — CI/CD, Fastlane et TestFlight en version simple
- 16.06 — Lire et reprendre un projet iOS existant
- 16.07 — Lecture rapide Objective-C, Realm et GraphQL
- 17.01 — Structure du mini projet final
- 17.02 — App complète : SwiftUI, MVVM, API, Firebase, persistance, tests, debug
